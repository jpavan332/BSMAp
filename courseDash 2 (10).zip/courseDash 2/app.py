from flask import (
        Flask,
        render_template,
        request,
        redirect,
        url_for,
        flash,
        make_response
)
from flask import jsonify
import json
from utils import xmlToDict, CourseMap
import os
from typing import Any, List, Dict
import math
from algo import Algo, algoUtil

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(10)

@app.route("/")
def home():
    schedule = xmlToDict(os.path.join(
                    os.path.abspath(
                        os.path.dirname(__file__)
                    ),
                    'static/Data/Schedule.xml'
            )
        )
    requirements = xmlToDict(os.path.join(
                    os.path.abspath(
                        os.path.dirname(__file__)
                    ),
                    'static/Data/BSCSDegreeReq.xml'
            )
        )

    course = json.load(open('static/Data/AllCourses.json'))
    hf = xmlToDict(os.path.join(
	                 os.path.abspath(
					    os.path.dirname(__file__) 
					 ),
					 'static/Data/HumanitiesAndFineArts.xml'
					 
			)
		)
    return render_template("index.html", schedule=schedule, course=course, requirements=requirements,hf=hf)

@app.route("/courses/table", methods=['GET'])
def courseTable():
    try:
        data = json.load(open("results.json"))
    except FileNotFoundError:
        data = None
    return render_template("tables.html", data=data)

import json
from flask import jsonify, request

def correctSingleQuoteJSON(s):
    rstr = ""
    escaped = False

    for c in s:
    
        if c == "'" and not escaped:
            c = '"' # replace single with double quote
        
        elif c == "'" and escaped:
            rstr = rstr[:-1] # remove escape character before single quotes
        
        elif c == '"':
            c = '\\' + c # escape existing double quotes
   
        escaped = (c == "\\") # check for an escape character
        rstr += c # append the correct json
    
    return rstr


@app.route("/courses/options",methods=['POST'])
def getOptions():
    data = request.get_json()
    data = correctSingleQuoteJSON(data)
    data  = json.loads(data)
    if isinstance(data, dict) and 'name' in data:
        subject = data['name']
        res = algoUtil.getOptions(data)
        response = jsonify({'orange': True, 'data':res})
        return res
    else:
        return jsonify({'success': False, 'message': 'Invalid data'})


@app.route("/courses/update",methods=['POST'])
def updateCourses():    
    data = request.get_json()
    print("type of data  - ",data, type(data))
    if isinstance(data, dict) and 'name' in data:
        print("isinstance is a map")
        subject = data['name']
        res = algoUtil.updateCourse(data)
        if len(res) >0 :
            print(res, "is res")
            response = jsonify({'orange': True, 'data':res})
            return res
        else:
            print("returning 500")
            return  make_response("Error course does't satisfy pre-requisites", 500)
    

@app.route("/create/map", methods=['POST'])
def courses():
    data = request.get_json()

    # save feed back to json file
    json.dump(data, open("selection.json", 'w'), indent=4)
    # add item to course map
    
    # check if number of semesters per year == 3 and total number of semesters 
    generateMap(data)
    # validate inputs
    # if data['availableCredits'] > baseMapper.getTotalCredits():
    #     return {
    #             'Message': 'The credit selected is less than the total credit allocated'
    #         }, 403
    return data

def generateMap(data):
        userSelection= json.loads(open("selection.json").read())
        
        algoUtil.add_data(data)
        print(data)
        algoUtil.createMap()
        while algoUtil.createMap() != 120:
            algoUtil.add_data(data)
            
        # convert list to Json
        # self.clientCourseMap.saveToJson()

@app.route("/update/map/<year>/<semester>/<coursename>", methods=["GET", "POST"])
def updateMap(year, semester, coursename):

    selection = json.loads(open("results.json").read())
    if request.method == 'GET':
        return render_template("update.html", selection=selection)
    
    year = int(year)
    new_semester = request.form.get("semester")
    new_year = request.form.get("year")

    data = json.loads(open("results.json").read())
    
    try:
        for element in data:
            for key, value in element.items():
                if int(key) == year:
                    for item1, item2 in value.items():
                        if item1 == semester:
                            for details in item2:
                                if details['name'] == coursename:
                                    item2.remove(details)
                                    
                                    # Check if the generated sum <= 21
                                    element[new_year][new_semester].append(details)

                                    # pop that element
    except:
        flash("Update Failed")
        return redirect(url_for("courseTable"))

    # replace the generated josn file
    json.dump(data, open("results.json", "w"), indent=4)

    return redirect(url_for("courseTable"))

def islistinstance(value) -> bool:
    return isinstance(value, list)


def getCredits(userlist) -> int:
    return sum([int(item['credit']) for item in userlist])

app.jinja_env.filters['islistinstance'] = islistinstance
app.jinja_env.filters['getSum'] = getCredits

if __name__ == '__main__':
    app.run(debug=True)
