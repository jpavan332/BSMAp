from __future__ import annotations

from typing import (
        Dict,
        Any,
        List,
        Iterable,
        Optional,
        TypeVar
)
import math
from algo import Algo
from collections import UserList
import xmltodict
from collections.abc import MutableMapping
import json
import collections

def xmlToDict(filename: str) -> Dict[str, Any]:
    with open(filename) as xml_file:
     
        data_dict = xmltodict.parse(xml_file.read())
    return data_dict


class Error(Exception):
    def __init___(self, message):
        self.message = message

    def __repr__(self):
        return f"{self.message!r}"


class MapCover(MutableMapping):
    class YearBase:
        def __init__(self, key, value):
            self.key = key
            self.value = value


T  = TypeVar('T', Dict[str, Any], Error)

class BaseMap(MapCover): 
    def __init__(self) -> None:
        self.results = []

    def __getitem__(self, key) -> Optional[T]:
        for elements in self.results:
            if elements.key == key:
                return elements.value
        raise Error("Year does not Exist")

    def __setitem__(self, key, value):
        # Create a mapping of year to map of pattern to Courses
        for elements in self.results:
            if elements.key == key:
                elements.value = value
                return
        self.results.append(self.YearBase(key, value))

    def __delitem__(self, key) -> None:
        for elements in self.results:
            if elements.key == key:
                del elements.key

    def __len__(self) -> int:
        return len(self.results)

    def __iter__(self):
        for elements in self.results:
            yield elements

    def getTotalCredits(self) -> int:
        sum: int = 0
        for elements in self.results:
            for key, value in elements.value.items():
                for data in value:
                    sum += int(data['credit'])
        return sum

    def saveToJson(self):
        out_ = []

        for elements in self:
            dictObj = {}
            dictObj[elements.key] = elements.value

            out_.append(dictObj)
        json.dump(out_, open("results.json", 'w'), indent=4)

class Courses:
    def __init__(self, subject, name, code, credit, prereq=None, parent=False, paired=[]) -> int:
        self.subject = subject
        self.name = name
        self.code = code
        self.credit = credit
        self.prerequisites: List[str] = prereq
        self.hasParent=parent
        self.paired: List[int] = paired 


    def getYears(self) -> int:
        res  = 0
        for i in range(1, 6):
            if isinstance(self.code, int):
                decoded_int = str(self.code)
                if decoded_int.startswith(str(i)):
                    res = i
        return res 

    def to_json(self):
        return {
                'subject': self.subject,
                'name': self.name,
                'code': self.code,
                'credit': self.credit,
                'prereq': self.prerequisites,
                "paired": self.paired
            }
    
    def __repr__(self) -> str:
        return f"{self.__class__.__qualname__}(subject={self.subject}, name={self.name!r}, code={self.code!r}, credit={self.credit!r}, prereq={self.prerequisites!r})"

class CourseMap:
    def __init__(self, userData):
        self.userData: Dict[str, Any] = userData
        self.all_courses: Dict[str, Any] = xmlToDict("./static/Data/Courses2016.xml")
        self.to_be_scheduled = []
        self.clientCourseMap = BaseMap()
        self.anual_sem = 2 if self.userData['summerAvailability'] == 'false' else 3
        self.total_study_years = math.ceil(self.userData['noOfSemesters'] / 3) if self.userData['summerAvailability'] == 'true' else  math.ceil(self.userData['noOfSemesters'] / 2) 

    def generateMap(self, key=None):
        self.userSelection= json.loads(open("selection.json").read())
        
        self.feedback = self.getCourseTermPattern()
        algoUtil = Algo()
        algoUtil.add_data(self.userData)
        print(self.userData)

        while algoUtil.createMap() != 120:
            algoUtil = Algo()
            algoUtil.add_data(self.userData)
            

        for key, value in self.feedback.items():
            self.clientCourseMap[key] = value

        # convert list to Json
        # self.clientCourseMap.saveToJson()

    def getCourses(self) -> List[Courses]:
        """
        Create Courses and the prerequisites
        """

        for courses in self.all_courses['descriptions']['course']:
            if courses['course_name'] not in self.userData['coursesPursued']:
                clientCourse = Courses(
                        subject=courses['subject'],
                        name=courses['course_name'],
                        code=courses['course_number'],
                        credit=courses['credit']
                    )
                # Check if course contains prereq
                if 'prerequisite' in courses.keys():
                    if 'or_choice' in courses['prerequisite'].keys():
                        if isinstance(courses['prerequisite']['or_choice'], list):
                            # extract course scode 
                            clientCourse.prerequisite = [
                                            item['and_required'] for item in courses['prerequisite']['or_choice']
                                    ]
                        else:
                            clientCourse.prerequisites = [courses['prerequisite']['or_choice']['and_required']]
                
                # Check if course contains paired
                if 'paired' in courses.keys():
                    res_ = []
                    
                    if isinstance(courses, list):
                        for items in courses['paired']:
                            res_.append(items)
                    else:
                        res_.append(courses['paired'])
                    clientCourse.paired = res_
                    clientCourse.hasParent = True

                self.to_be_scheduled.append(clientCourse)
        self.to_be_scheduled = sorted(self.to_be_scheduled, key=lambda x: int(x.code))
        return self.to_be_scheduled
        
    def splitCourses(self) -> List[List[Courses]]:
        courses = self.getCourses()
        out_ = [[] for _ in range(self.userData['noOfSemesters'])] # list of empty lists for each semester
    
        self.paired_courses = sorted([course for course in self.to_be_scheduled if len(course.paired) > 0], key=lambda x: int(x.code))

        used_codes = set()  # set to keep track of used course codes
       
        # continue generating map if the sum of the total credits <= 120

        totalCredits = 0

        while totalCredits < self.userData['availableCredits']:
            # check the Length of Out)
            for semester in range(self.userData['noOfSemesters']):
                # Total credits <= given credits
                credits = 0  # total credit for the semester
                semwise_units = []
                for course in courses:
                    if not '-' in course.credit:
                        if course.code not in used_codes:
                            if credits + int(course.credit) <= 21:
                                # remove the code from the list
                                used_codes.add(course.code)
                                credits += int(course.credit)
                                # adjust total credit
                                totalCredits += int(course.credit)
                                semwise_units.append(course.to_json())
                                courses.remove(course)
                out_[semester] = semwise_units

        return out_
    
    def getCourseTermPattern(self) -> Dict[str, Iterable]:
        self.rotations = xmlToDict("./static/Data/Schedule.xml")
       
        courses = self.splitCourses()
        
        # Group Semesters into FS / SP and SS courses and display output in Json For looping by the table
        
        x = ["FS", "SS", "SP"] if self.anual_sem == 3 else ["FS", "SP"] 

        
        pertake = []
        # use the generated list to chain a list of courses and semseters
        
        for i in range(self.userData['noOfSemesters']):
            pertake.append(x[i % len(x)])

        # semesters = [pertake[n:n+3] for n in range(0, len(pertake), 3)]
        semesters = pertake

        mapping = {semester: courses for semester, courses in zip(semesters, courses)}
    

        self.dict_obj = {}
        
        if len(courses)> 0:
            for i in range(self.total_study_years):
                # split map into number of courses per semester
                # Delete the index from the self.to_be_scheduled
                data = {}
                for j in range(len(semesters)):
                    evaluate = (i+j) % self.total_study_years
                    data[semesters[j]] = courses[evaluate]
                self.dict_obj[i+1] = data
    
        return self.dict_obj


    def getTotalCredits(self) -> int:
        return self.clientCourseMap.getTotalCredits()

