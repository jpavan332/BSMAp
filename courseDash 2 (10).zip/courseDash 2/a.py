

ls = [1,2,3,4,5,6]

while(len(ls)>0):
    print(ls)
    ls.pop(1)

