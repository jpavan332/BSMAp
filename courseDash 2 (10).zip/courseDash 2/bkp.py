import json
import random


class Algo:
    def __init__(self,courseMap = None):
        self.courses = json.loads(open("./static/Data/AllCourses.json").read())["courses"]
        self.courseByName = self.populate_course_names()
        self.needed = dict()
        self.have = dict()
        self.completed = []
        self.order = self.findOrder()
        self.fill_list = []
        
    
    def populate_course_names(self):
        for course in self.courses:
            name = course['subject'] + ' ' + course['course_number']
            self.courseByName[name] = course
            course['name'] = name
            
    def has_prerequisites(self,course):
        if 'prerequisites' not in course:
            return False
        
        prereq = course['prerequisites']
        if 'or_choice' not in prereq or len(prereq['or_choice']):
            return False
        
        return True

    def get_prerequisites(self,course,k = 0):
        if 'prerequisites' not in course:
            return []

        prereq = course['prerequisites']
        if 'or_choice' not in prereq or len(prereq['or_choice']) == 0:
            return []
        
        or_choice = prereq['or_choice']
        if len(or_choice) <= k:
            return []
        return or_choice[k]['and_required']

    def get_all_prereq(self,course):
        prereq = []
        k = 0
        should_pick_all =self.get_prerequisites(course, k)
        while len(should_pick_all) != 0:
            prereq.extend(should_pick_all)
            k += 1
            should_pick_all = self.get_prerequisites(course,k)
        return prereq

    def can_pickup_course(self,course,completed_courses):
        k = 0
        if course in completed_courses:
            return False
        
        should_pick_all = self.get_prerequisites(course, k)
        if len(should_pick_all) == 0:
            return True
        while len(should_pick_all) > 0:
            done = True
            for prereq in should_pick_all:
                if prereq not in completed_courses:
                    done = False
            if done:
                return True
            k = k+1
            should_pick_all = self.get_prerequisites(course,k)
        
        return False

# def completed_prereq(course, visited):


    def dfs(self,course_name,visited_courses, topological_order):

        course = self.courseByName[course_name]
        visited_courses.append(course_name)
        for nextCourse in self.get_all_prereq(course):
            if nextCourse in self.courseByName and nextCourse not in visited_courses:
                self.dfs(nextCourse, visited_courses, topological_order)

        topological_order.append(course['name'])

    def findOrder(self):
        visited_courses = []
        topological_order =[]
        for c in self.courses:
            if c not in visited_courses:
                self.dfs( c['name'], visited_courses,topological_order)

        unique_order = []
        for ele in topological_order:
            if ele not in unique_order:
                unique_order.append(ele)
        return unique_order


    def validateOrder(self):
        visited = []

        for course_name in self.order:
            course = self.courseByName[course_name]
            if not self.can_pickup_course(course, visited):
                print('this course',course_name ,'is not done properly')
            visited.append(course_name)

    def getMandatoryCourses(self):

        mandatory_courses = []
        for courseName in self.order:
            course = self.courseByName[courseName]
            if "mandatory" in course and course["mandatory"] == True:
                mandatory_courses.append(courseName)
        
        return mandatory_courses


    def getGenElectiveCourses(self,order, courseByName):
        gen_elective_courses = []

        for courseName in order:
            course = courseByName[courseName]
            if ("mandatory" not in course or course["mandatory"] == False) and course["subject"][:3] =="CMP":
                gen_elective_courses.append(courseName)
            
            elif "genEd" in course:
                gen_elective_courses.append(courseName)
        
        return gen_elective_courses



    def getHumanityCourses(self):
        humanity_courses = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "Humanities":
                humanity_courses.append(courseName)

        return humanity_courses


    def getSocialScienceCourses(self):
        social_sci_courses = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "SocialandBehaviouralScience":
                social_sci_courses.append(courseName)

        return social_sci_courses

    def getFirstYearEngCourses(self):
        first_english = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "WrittenAndOral" and course["subject"] == "ENGL":
                first_english.append(courseName)
        
        return first_english

    def getCommProfCourses(self,order,courseByName):
        comm_prof_courses = []

        for courseName in order:
            course = courseByName[courseName]
            if "genEd" in course and course["genEd"] == "WrittenAndOral" and course["subject"] == "COMM":
                comm_prof_courses.append(courseName)
        
        return comm_prof_courses

    def getAmericanHistory(self):

        american_history_courses = []
        for courseName in self.order:
            course = self.courseByName[courseName]
            if courseName[:8] == "American":
                american_history_courses.append(courseName)
            
        return american_history_courses

    def getSumOfCredits(self,courseNames):
        sum =0
        for cn in courseNames:
            sum += self.courseByName[cn]["credit"]
        return sum


    def getAcourse(self,ls,maxCredit):
        
        idx = 0
        for courseName in ls:
            credit = self.courseByName[ls[idx]]["credit"]
            if credit <= maxCredit + 4 and courseName not in self.completed:
                ls.pop(idx)
                return courseName, ls
            idx+=1

        return "EMPTY",ls

    def getRandomPick(self,pickOrder):
        
        ls = []
        for ele in pickOrder:
            if self.needed[ele] > 0 and len(self.have[ele]) > 0:
                ls.append(ele)
        
        pickOrder = ls
        #include logic for semesters
        idx = int(random.random() % len(pickOrder))
        return pickOrder[idx],pickOrder


    def fillSemester(self, credits,pickOrder):
        semester = []
        semester_credits = 0

        while credits > 0:
            pick, pickOrder = self.getRandomPick(pickOrder)
            courseName,self.have[pick] = self.getAcourse(self.have[pick],credits)
            semester.append(courseName)
            creditHere = self.courseByName[courseName]["credit"]
            semester_credits += creditHere
            credits -= creditHere
            self.needed[pick] -= creditHere
            self.completed.append(courseName)
        
        return semester,semester_credits

    def createMap(self):
        
        taken = set()

        self.fill_list = ["mandatory_courses","american_history_courses","junior_level_english_courses","first_year_courses","comm_prof_courses"]
        
        self.needed["mandatory_courses"] = 52
        self.have["mandatory_courses"] = self.getMandatoryCourses()

        self.needed["american_history_courses"] = 3
        self.have["american_history_courses"] = self.getAmericanHistory()

        self.needed["junior_level_english_courses"] = 3
        self.have["junior_level_english_courses"] = ""

        self.needed["first_year_courses"] = 3
        self.have["first_year_courses"] = self.getFirstYearEngCourses()
        
        self.needed["comm_prof_courses"] = 3
        self. have["comm_prof_courses"] = self.getCommProfCourses()

        self.needed["gen_elective_courses"] = 15
        self.have["gen_elective_courses"] = self.getGenElectiveCourses()
        
        self.needed["social_sciences_courses"] = 9
        self.have["social_sciences_courses"] = self.getSocialScienceCourses()

        self.needed["humanity_courses"] = 9
        self.have["humanity_courses"] = self.getHumanityCourses()
    
        total_needed = 97
        
        pickOrder =[ "first_year_courses","comm_prof_courses","mandatory_courses","american_history_courses","gen_elective_courses","humanity_courses","social_sciences_courses"]

        required_per_sem = total_needed / self.numSemesters
        if required_per_sem > 21:
            print("impossible")
            return

        semesters = []
        numSem = 1
        total_completed = 0
        for i in range(1,self.numSemesters+1):
            neededHere = min(required_per_sem,  total_needed - required_per_sem)
            semester,semester_credits = self.fillSemester(neededHere,pickOrder)
            total_needed -= semester_credits
            total_completed += semester_credits
            print(semester_credits, semester)
            semesters.append(semester)
            print('completed',numSem, total_needed,total_completed)
            numSem += 1
        
        return semesters


algo = Algo()

print(algo.createMap())



'''

mandatory -> take all (67 credits)

general electives -> 15 credits from any course


gen_ed can be taken up to max 42 credits and minimum 27

humanities and fine arts ->  9 credits genedcol = humanities

social and sciences -> 9 credits (genED col = SocialandBehaviouralScience)

first-year-courses -> 3 crdits genED= WrittenAndOral

communication proficiency ->3 credits "genEd": "WrittenAndOral"

american history -> 3 credits (course_name prefix = "american")

other Requirements				- 3credits

Junior Level English Competiton[ENGL3130, make a entry ]	- 3credits




+ math pre-requisties




'''

