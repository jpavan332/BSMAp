// Academic Background

const continueRadioBtn = document.querySelector("#continue")
// const firstTimeBtn = document.querySelector("#first")

// get empty Div
var hiddenCourse = document.querySelector(".hidden-course");

// append div to hidden course
var allCourses = document.querySelector(".courses");
if(continueRadioBtn !==null){

	continueRadioBtn.addEventListener("change", () => {
		// make the Div Visible
		hiddenCourse.append(allCourses)

		allCourses.classList.add('display-block')
		hiddenCourse.classList.add("show-courses");
	})


// firstTimeBtn.addEventListener("change", () => {
// 	// Remove hidden Div

// 	hiddenCourse.classList.remove("show-courses");

// 	allCourses.classList.remove("display-block");

// 	hiddenCourse.removeChild(allCourses);
// })


// summer Availability Validator
document.querySelector('#summerNo').addEventListener("change", () => {
	document.querySelector("#Summer").disabled = true;
})

document.querySelector('#summerYes').addEventListener("change", () => {
	document.querySelector("#Summer").disabled = false;
})

const createMapForm = document.querySelector(".createCourseMap");


createMapForm.addEventListener("submit", (event) => {
	event.preventDefault();

	var coursesPursued = [];

	// get Available credits
	var availableCredits = 120;
	// Check Summer Availability

	var summerAvailability = document.querySelector('input[name="summer"]:checked').value;
	// Check number of semesters available for study
	//
	var noOfSemesters = document.querySelector('#semesters').value;


	var resumption = document.querySelector("input[name='resumption']:checked").value;

	//  Check number of semesters pursued
	if (continueRadioBtn.checked) {
		// Only submitted courses if continue radio button is checked
		var selected = document.querySelectorAll(".courses input")

		for (let i = 0; i <= selected.length; i++) {
			// get checked radio buttons values
			if (selected[i] !== undefined && selected[i].checked === true) {
				coursesPursued.push(selected[i].value)
			}
		}
	}

	// post data to server
	fetch(`${window.origin}/create/map`, {
		method: 'POST',
		headers: new Headers({
			'Content-Type': 'application/json'
		}),
		body: JSON.stringify(
			{
				'availableCredits': parseInt(availableCredits),
				'summerAvailability': summerAvailability,
				'noOfSemesters': parseInt(noOfSemesters),
				'coursesPursued': coursesPursued,
				'courseResumption': resumption
			}
		)
	}).then((response) => {
		if (response.status === 200) {
			window.location = `${window.origin}/courses/table`
		}

		if (response.status === 403) {
			alert("The credit selected is less than the total credit allocated")
		}
	}).catch((error) => console.log(error))


})

}

function openModal(responseData) {
	var modal = document.getElementById("myModal");
	var dropdown = document.getElementById("myDropdown");
	// Clear existing options
	dropdown.innerHTML = "";
	const options = responseData[0]
	// Create new options based on response data
	options.forEach(function (option) {
		var optionElement = document.createElement("option");
		optionElement.textContent = option;
		dropdown.appendChild(optionElement);
	});
	var button = document.createElement("button");
	button.id = "myButton";
  button.className = "myButtonClass"; // Add the desired class name
	button.textContent = "Save";
	button.onclick = function () {
		saveData(responseData[1]); // Call updateValue with the parameter
	};

	modal.querySelector(".modal-content").appendChild(button);


	modal.style.display = "block";
}

function handleClick(data) {
	console.log(data, "data-modify")


	// console.log(jsonData); // DATA OF SELECTED BUTTON ROW
	fetch(`${window.origin}/courses/options`, {  // TO GET OPTIONS FOR DROPDOWN
		method: 'POST',
		headers: new Headers({
			'Content-Type': 'application/json'
		}),
		body: JSON.stringify(data)
	})
		.then((response) => response.text())
		.then(responseData => {
			const data = JSON.parse(responseData);
			console.log(data);
			openModal(data)

		})
		.catch(error => console.log(error));
}

function closeModal() {
	var modal = document.getElementById("myModal");
	modal.style.display = "none";
	document.body.classList.remove("modal-open");
	var buttonToRemove = document.getElementById("myButton");
      if (buttonToRemove) {
        buttonToRemove.remove();
      }
      modal.style.display = "none";
}

// function updateValue() {
// 	var dropdown = document.getElementById("myDropdown");
// 	var selectedValue = dropdown.value;
// 	// Perform any actions you want with the selected value
// 	console.log("Selected value: " + selectedValue);
// }

function saveData(data) {
	var dropdown = document.getElementById("myDropdown");
	var selectedOption = dropdown.value;
	console.log(selectedOption)
	console.log(data)
	// Fetch additional data based on the selected option if needed
	var dataToSend = {
		selectedOption: selectedOption,
		...data
	};

	console.log(dataToSend)
	body = JSON.stringify(dataToSend)
	console.log(body)

	// Perform save operation or send data to server
	fetch(`${window.origin}/courses/update`, {
		method: 'POST',
		headers: new Headers({
			'Content-Type': 'application/json'
		}),
		body: body
	}).then((response) => {
		if (response.status === 200) {
			window.location = `${window.origin}/courses/table`
		}else {
			alert(`Prerequisites are not satisfied for ${selectedOption}`)
		}
	}).catch((error) => console.log(error))


	closeModal();
}


// modal.addEventListener("click", function(event) {
//     if (event.target === modal) {
//       // Remove the button when the modal is closed
//       modal.querySelector(".modal-content").removeChild(button);
//       modal.style.display = "none";
//     }
//   });
function downloadPDF() {

	var contentHeight = document.body.offsetHeight - 20;  // Subtract 20pt for a 10pt top and bottom gap
  
	var options = {
	  filename: 'coursemap.pdf',  // Set the filename of the downloaded PDF
	  image: { type: 'jpeg', quality: 0.98 },  // Set the image quality
	  html2canvas: { scale: 1 },  // Set the scale of the HTML elements to be converted to PDF
	  jsPDF: { unit: 'pt', format: 'letter', orientation: 'portrait', height: contentHeight }  // Set the size and orientation of the PDF
	};
  
	html2pdf().set(options).from(document.body).save();
  }
