


import json


data = json.load(open("AllCourses.json"))

data = data["courses"]

def isMandatory(c):
    return ("mandatory" in c) and (c["mandatory"] == True)


ls = []
for c in data:
    if  not isMandatory(c) and c["subject"] == "CMP SCI" and c["course_number"][:1] == "3":
        ls.append(c)

for c in ls:
    print(c["subject"] + " " + c["course_number"])


def get_prerequisites(course,k = 0):
        if 'prerequisites' not in course:
            return []

        prereq = course['prerequisites']
        if 'or_choice' not in prereq or len(prereq['or_choice']) == 0:
            return []
        
        or_choice = prereq['or_choice']
        if len(or_choice) <= k:
            return []
        return or_choice[k]['and_required']

prereq = dict()

list_of_Pres = []

for c in ls:
    cname = c["subject"] + " " + c["course_number"]
    preHere = get_prerequisites(c,0)
    list_of_Pres += preHere
    prereq[cname] = preHere

for r in prereq:
    print(r, prereq[r])



print(set(list_of_Pres))


# for p in list_of_Pres:
#     cname = p["subject"] + " " + p["course_number"]
#     preHere = get_prerequisites(p,0)
#     print("for ",cname," = ",preHere)



'''
CMP SCI 3200
CMP SCI 3410
CMP SCI 3411
CMP SCI 3702
CMP SCI 3780

'''