import json
import random,math


#user-data : {'availableCredits': 120, 'summerAvailability': 'true', 'noOfSemesters': 8, 'coursesPursued': [], 'courseResumption': 'Fall'}
class Algo:

    def __init__(self,userData = None):
        pass
        # self.userData = userData
        # self.total_needed = self.userData["availableCredits"]
        # self.num_semesters = self.userData["noOfSemesters"]
        # self.summer_availability = self.userData["summerAvailability"]
        # self.pursed_courses = self.userData["coursesPursued"]
        
        # self.course_resumption = self.userData["courseResumption"]
        
        # self.courses = json.loads(open("./static/Data/AllCourses.json").read())["courses"]
        # self.courseByName = dict() 
        # self.populate_course_names()
        # self.needed = dict()
        # self.have = dict()
        # self.completed = []
        # self.order = self.findOrder()
        # self.fill_list = []
        # self.semesters = []
        # self.numSemesters = 8


    def add_data(self, userData):
        self.userData = userData
        self.total_needed = self.userData["availableCredits"]
        self.num_semesters = self.userData["noOfSemesters"]
        self.summer_availability = self.userData["summerAvailability"]
        self.courses_pursued = self.userData["coursesPursued"]
        self.pursed_credits = 0
        self.completed = []

        self.course_resumption = self.userData["courseResumption"]
        
        self.courses = json.loads(open("./static/Data/AllCourses.json").read())["courses"]
        self.courseByName = dict() 
        self.populate_course_names()
        self.needed = dict()
        self.have = dict()
        self.order = self.findOrder()
        self.fill_list = []
        self.semesters = []
        self.mandatory_needed = 0
        self.normal_needed = 0
        self.numSemesters = self.userData["noOfSemesters"]
        self.movable = []

    
    def populate_course_names(self):
        for course in self.courses:
            name = course['subject'] + ' ' + course['course_number']
            self.courseByName[name] = course
            course['name'] = name
            
    def has_prerequisites(self,course):
        if 'prerequisites' not in course:
            return False
        
        prereq = course['prerequisites']
        if 'or_choice' not in prereq or len(prereq['or_choice']):
            return False
        
        return True

    def get_prerequisites(self,course,k = 0):
        if 'prerequisites' not in course:
            return []

        prereq = course['prerequisites']
        if 'or_choice' not in prereq or len(prereq['or_choice']) == 0:
            return []
        
        or_choice = prereq['or_choice']
        if len(or_choice) <= k:
            return []
        return or_choice[k]['and_required']

    def get_all_prereq(self,course):
        prereq = []
        k = 0
        should_pick_all =self.get_prerequisites(course, k)
        while len(should_pick_all) != 0:
            prereq.extend(should_pick_all)
            k += 1
            should_pick_all = self.get_prerequisites(course,k)
        return prereq

    def can_pickup_course(self,course,completed_courses):
        k = 0
        if course in completed_courses:
            return False
        
        should_pick_all = self.get_prerequisites(course, k)
        if len(should_pick_all) == 0:
            return True
        while len(should_pick_all) > 0:
            done = True
            for prereq in should_pick_all:
                if prereq not in completed_courses:
                    done = False
            if done:
                return True
            k = k+1
            should_pick_all = self.get_prerequisites(course,k)
        
        return False

# def completed_prereq(course, visited):

    def dfs(self,course_name,visited_courses, topological_order):

        course = self.courseByName[course_name]
        visited_courses.append(course_name)
        for nextCourse in self.get_all_prereq(course):
            if nextCourse in self.courseByName and nextCourse not in visited_courses:
                self.dfs(nextCourse, visited_courses, topological_order)

        topological_order.append(course['name'])

    def findOrder(self):
        visited_courses = []
        topological_order =[]
        for c in self.courses:
            if c not in visited_courses:
                self.dfs( c['name'], visited_courses,topological_order)

        unique_order = []
        for ele in topological_order:
            if ele not in unique_order:
                unique_order.append(ele)
        return unique_order


    def validateOrder(self):
        visited = []

        for course_name in self.order:
            course = self.courseByName[course_name]
            if not self.can_pickup_course(course, visited):
                print('this course',course_name ,'is not done properly')
            visited.append(course_name)

    def getMandatoryCourses(self):
        sum = 0
        mandatory_courses = []
        for courseName in self.order:
            course = self.courseByName[courseName]
            if "mandatory" in course and course["mandatory"] == True:
                mandatory_courses.append(courseName)
                sum += course["credit"]
        
        return mandatory_courses
    
    def isMandatory(self, c):
        return ("mandatory" in c) and (c["mandatory"] == True)

    def getComputerScienceElectives(self):
        comp_electives = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            flag = (course["course_number"][:1] =='3' or course["course_number"][:1]== '4')
            if course["subject"] =="CMP SCI" and flag and not self.isMandatory(course) :
                comp_electives.append(courseName)
            
        return comp_electives

    def getGenElectiveCourses(self):
        gen_elective_courses = []

        for courseName in self.order:
            if courseName not in self.completed:
                gen_elective_courses.append(courseName)
        
        return gen_elective_courses
    
    def getGeneralComputerScienceElectives(self):
        gen_comp = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] != "MathScience":
                gen_comp.append(courseName)
        
        return gen_comp

    def getMathCourses(self):
        math_courses = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "MathScience":
                math_courses.append(courseName)
        
        return math_courses

    def getHumanityCourses(self):
        humanity_courses = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "Humanities":
                humanity_courses.append(courseName)

        return humanity_courses


    def getSocialScienceCourses(self):
        social_sci_courses = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "SocialandBehaviouralScience":
                social_sci_courses.append(courseName)

        return social_sci_courses

    def getFirstYearEngCourses(self):
        first_english = []

        for courseName in self.order:
            course = self.courseByName[courseName]

            
            if "genEd" in course and course["genEd"] == "WrittenAndOral" and course["subject"] == "ENGL":
                first_english.append(courseName)
                print("ENGLISH COURSES============",course)
        
        return first_english

    def getCommProfCourses(self):
        comm_prof_courses = []

        for courseName in self.order:
            course = self.courseByName[courseName]
            if "genEd" in course and course["genEd"] == "WrittenAndOral" and course["subject"] == "COMM":
                comm_prof_courses.append(courseName)
        
        return comm_prof_courses

    def getAmericanHistory(self):

        american_history_courses = []
        for courseName in self.order:
            course = self.courseByName[courseName]
            if course["course_name"][:8] == "American":
                american_history_courses.append(courseName)
        
        return american_history_courses
    
    def getJuniorLevelEnglish(self):
        return ["ENGL 3130"]    


    def getSumOfCredits(self,courseNames):
        sum =0
        for cn in courseNames:
            sum += self.courseByName[cn]["credit"]
        return sum


    def getAcourse(self,ls,maxCredit,semNum):
        
        idx = 0
        offset = 3
        for courseName in ls:
            credit = self.courseByName[ls[idx]]["credit"]
            if credit <= maxCredit + offset and courseName not in self.completed:
                ls.pop(idx)
                return courseName, ls
            idx+=1

        return "EMPTY",ls
    
    def prepareMandatoryList(self):
        nonman = []
        mand = self.getMandatoryCourses()
        for c in mand:
            pre = self.get_prerequisites(self.courseByName[c],0)
            nonman += pre
        
        nonman = set(nonman)

        nonman = list(nonman)

        conc = []
        i = 0
        j = 0
        for c in self.order:
            if c in nonman:
                conc.append(c)
            elif c in  mand:
                conc.append(c)
                
        
        return conc
    

    def saveToJson(self,data, file):
        with open(file, "w") as outfile:
            json.dump(data, outfile, indent=4)

    def getRandomPick(self,pickOrder):
        
        ls = []
        for ele in pickOrder:
            if self.needed[ele] > 0 and len(self.have[ele]) > 0:
                ls.append(ele)
        
        pickOrder = ls
        print(pickOrder)
        #include logic for semesters
        maxRange = len(pickOrder)-1
        if maxRange > 3:
            maxRange -= 1
        idx = random.randint(0,maxRange) 
        return pickOrder[idx],pickOrder

    def convertToResponseFormat(self,courseName,pick,semNum=1):
        course = self.courseByName[courseName]

        res = dict()
        # res["subject"] = course["subject"]  if pick in self.fill_list else "----"
        # res["code"] = course["course_number"] if pick in self.fill_list else "----"
        # res["name"] = course["course_name"]  if pick in self.fill_list else pick
        # res["credit"] = course["credit"]   if pick in self.fill_list else 0
        # res["paired"] = []
        # res["semester"] = semNum
        res["subject"] = course["subject"]  
        res["code"] = course["course_number"] 
        res["name"] = course["course_name"]
        res["credit"] = course["credit"]   
        res["paired"] = []
        res["options"] = "FALSE" if pick in self.fill_list else "TRUE"
        res["options_type"] = pick
        res["semester"] = semNum

        # if pick == "mandatory_courses":
        #     res["name"] = "mandatory"
        return res
        
           
    def separateSemesterPerYears(self):
        seasons = self.getSeasons()
        years = dict()

        y = 0
        
        for i in range(len(self.semesters)):
            if len(self.semesters[i]) == 0:
                continue
            if i %len(seasons) == 0:
                y+=1

            if  y not in years:
                years[y] = dict()
            
            season = seasons[i%len(seasons)]
            years[y][season] = self.semesters[i]
        
        yearList = []
        for yr in years:
            d = dict()
            d[yr] = years[yr]
            yearList.append(d)
        return yearList
    


    def fillSemester(self, credits,pickOrder,semNum):
        semester = []
        semester_credits = 0
        cnt = 0
        while credits > 0:
            pick, pickOrder = self.getRandomPick(pickOrder)
            courseName,self.have[pick] = self.getAcourse(self.have[pick],credits,semNum)
            if courseName == "EMPTY":
                print("picked EMPTY",pick,self.needed[pick],self.have[pick])
                break
            resp = self.convertToResponseFormat(courseName,pick,semNum)
            semester.append(resp)

            self.completed.append(resp["name"])

            creditHere = self.courseByName[courseName]["credit"]
            semester_credits += creditHere

            credits -= creditHere
            self.needed[pick] -= creditHere
            self.completed.append(courseName)
            cnt+=1
        
        return semester,semester_credits

    def getSeasons(self):
        if self.course_resumption == "Fall":
            if self.summer_availability == "true":
                return ["FS","SP","SS"]
            return ["FS","SP"]
        
        if self.course_resumption == "Spring":
            if self.summer_availability == "true":
                return ["SP","SS","FS"]
            return ["SP","FS"]
        
        return ["SS","FS","SP"]
    

    def markCompletedCourses(self):
        mand_comp = 0
        norm_comp = 0
        for cname in self.courses_pursued:
            course = self.getByCourseName(cname)
            subname = course["subject"] + " " + course["course_number"]
            if subname in self.have["mandatory_courses"]:
                mand_comp += course["credit"]
            else:
                norm_comp += course["credit"]
            
            self.completed.append(course["subject"] + " " + course["course_number"])
        return mand_comp, norm_comp
    
    def getSemCredits(self, semNum):
        cnt = 0
        for c in self.semesters[semNum]:
            cnt += c["credit"]
        return cnt
    
    def getASubToMove(self, semNum):

        for i in range(len(self.semesters[semNum])):
            course = self.semesters[semNum][i]
            if course["options_type"] in self.movable :
                return course

        return None
    
    def moveCourse(self, course, i, j):
        ls = []
        courseName = course["subject"] + " " + course["code"]
        print("moving course ", courseName, "from ",i, " to",j)
        for c in self.semesters[i]:
            cname = c["subject"] + " " + c["code"]
            if  cname != courseName:
                ls.append(c)
        self.semesters[i] = ls
        self.semesters[j].append(course) 

    def moveCoursesIfNeeded(self):
        for _ in range(5):
            for i in range(0,len(self.semesters)):
                sem_creds = self.getSemCredits(i)
                if sem_creds <= 21: continue

                cMove = self.getASubToMove(i)
                if cMove == None:
                    continue

                for j in range(i+1, len(self.semesters)):
                    if self.getSemCredits(j) + cMove["credit"]  <= 21:
                        self.moveCourse(cMove, i,j)


    def createMap(self):       
        with open("results.json",'w') as file:
            pass 

        self.fill_list = ["mandatory_courses","American History","junior_level_english_courses","First Year Courses","Communication Proficiency","Cultural Diversity", "Math Courses"]
        self.movable = [ "American History","First Year Courses","Junior Level English",
                    "Communication Proficiency","General Electives","Math Courses",
                    "Humanities and Fine Arts","Social Sciences","Cultural Diversity"]
        
        self.needed["mandatory_courses"] = 60
        self.have["mandatory_courses"] = self.prepareMandatoryList()

        self.needed["American History"] = 3
        self.have["American History"] = self.getAmericanHistory()

        self.needed["Junior Level English"] = 3
        self.have["Junior Level English"] = self.getJuniorLevelEnglish()

        self.needed["First Year Courses"] = 3
        self.have["First Year Courses"] = self.getFirstYearEngCourses()
        
        self.needed["Communication Proficiency"] = 3
        self. have["Communication Proficiency"] = self.getCommProfCourses()

        self.needed["General Computer Science Electives"] = 0
        self.have["General Computer Science Electives"] = self.getGeneralComputerScienceElectives()
        
        self.needed["Social Sciences"] = 9
        self.have["Social Sciences"] = self.getSocialScienceCourses()

        self.needed["Humanities and Fine Arts"] = 9
        self.have["Humanities and Fine Arts"] = self.getHumanityCourses()

        self.needed["Computer Science Electives"] = 15
        self.have["Computer Science Electives"] = self.getComputerScienceElectives()

        self.needed["Cultural Diversity"] = 3
        self.have["Cultural Diversity"] = ["CDA 1234"]

        self.needed["Math Courses"] = 3
        self.have["Math Courses"] = self.getMathCourses()
        
        self.needed["General Electives"] = 6
        self.have["General Electives"] = self.getGenElectiveCourses()

        completed_mandatory, completed_normal = self.markCompletedCourses()

        completed_count = completed_mandatory + completed_normal
        self.pursed_credits = completed_count

        self.mandatory_needed = 60 - completed_mandatory
        self.normal_needed = 60 - completed_normal

        self.total_needed -= completed_count
        tot = self.total_needed
        
        if tot/self.numSemesters > 21:
            print("impossible")
            #error case handling here
            return
        
        pickOrder =[ "mandatory_courses"]
        
        self.semesters1 = []
        numSem = 1
        mand_comp = 0

        required_per_sem = self.mandatory_needed / self.numSemesters
        if required_per_sem > 21:
            print("impossible")
            return
        

        while(numSem <= self.num_semesters):
            remSem = self.num_semesters - numSem + 1
            required_per_sem = self.mandatory_needed/(remSem)
           
            neededHere = min(required_per_sem, self.mandatory_needed)
            semester,semester_credits = self.fillSemester(neededHere,pickOrder,numSem-1)
            self.mandatory_needed -= semester_credits
            mand_comp += semester_credits
            self.semesters1.append(semester)
            numSem += 1

        pickOrder =[ "American History","First Year Courses","Junior Level English",
                    "Communication Proficiency",
                    "General Computer Science Electives","General Electives","Math Courses",
                    "Humanities and Fine Arts","Social Sciences","Cultural Diversity","Computer Science Electives"]
        
        self.semesters2 = []
        numSem = 1
        norm_comp = 0

        required_per_sem = math.ceil(self.normal_needed / self.numSemesters)
        if required_per_sem > 21:
            print("impossible")
            return
        
        while(numSem <= self.num_semesters):
            neededHere = min(required_per_sem, self.normal_needed)
            
            semester,semester_credits = self.fillSemester(neededHere,pickOrder,numSem-1)
            self.normal_needed -= semester_credits
            norm_comp += semester_credits
            self.semesters2.append(semester)
            numSem += 1

        # self.semesters = self.semesters2

        for i in range(self.numSemesters):
            self.semesters.append([])
            for c in self.semesters1[i]:
                self.semesters[i].append(c)
            
            for c in self.semesters2[i]:
                self.semesters[i].append(c)
            
        
        self.moveCoursesIfNeeded()

        years = self.separateSemesterPerYears()
        print("total_pursued",completed_normal, completed_mandatory,self.pursed_credits)
        print("needed",self.normal_needed,self.mandatory_needed)
        print("total_completed",norm_comp, mand_comp, (norm_comp + mand_comp),(norm_comp + mand_comp + self.pursed_credits) )
        self.saveToJson(years,"results.json")
        return norm_comp + mand_comp + self.pursed_credits

    def filterCompleted(self,courses):
        ls = []
        for c in courses:
            if c not in self.completed:
                ls.append(c)
        return ls
    

    def getCompleteNamesOfCourses(self,options):
        ls = []
        for name in options:
            c = self.courseByName[name]
            ls.append(c["course_name"])
        return ls


    def filterCredits(self,options,credit):
        ls = []
        for c in options:
            course = self.courseByName[c]
            if course["credit"] == credit:
                ls.append(c)

        return ls

    def getOptions(self,dataMap):
        
        subject = dataMap['options_type']
        options = []

        if subject == "General Electives":
            options =  self.getGenElectiveCourses()

        elif subject == "Humanities and Fine Arts":
            options = self.getHumanityCourses()
        
        elif subject == "Social Sciences":
            options = self.getSocialScienceCourses()
        
        if subject == "Computer Science Electives":
            options = self.getComputerScienceElectives()
        
        options = self.filterCompleted(options)
        options = self.filterCredits(options,dataMap['credit'])

        optionNames = self.getCompleteNamesOfCourses(options)
       
        return [optionNames, dataMap]
    

    def getByCourseName(self, name):
        for c in self.courses:
            if c["course_name"] == name:
                return c

    def updateSemester(self, semNum, currentSubject, optionSelected):
        
        course = self.getByCourseName(optionSelected)
        idx = 0
        while idx < len(self.semesters[semNum]):
            if self.semesters[semNum][idx]["name"] == currentSubject:
                break
            idx+=1
        
        res = dict()
        res["subject"] = course["subject"]  
        res["code"] = course["course_number"] 
        res["name"] = course["course_name"] 
        res["credit"] = course["credit"]   
        res["paired"] = []
        res["semester"] = semNum

        course_name_code =course["subject"] + " " + course["course_number"]
        self.completed.append(course_name_code)
        self.semesters[semNum][idx] = res

        return semNum


    def updateCourse(self, data):
        

        semNum =data["semester"]
        currentSubject = data["name"]
        optionSelected = data["selectedOption"]
        
        compCourses = []
        compCourses += self.courses_pursued
        for i in range(semNum):
            for c in self.semesters[i]:
                cname = c["subject"] + " " + c["code"]
                compCourses.append(cname)
        
        c = self.getByCourseName(optionSelected)
        satisfied = True
        k = 0
        should_pick_all = self.get_prerequisites(c,k)
        if(len(should_pick_all) > 0):
            satisfied = False
        while len(should_pick_all) > 0:
            k += 1
            done = True
            for prereq in should_pick_all:
                if prereq not in compCourses:
                    done = False
            
            if done:
                satisfied = True
                break
            should_pick_all = self.get_prerequisites(c,k)
        if not satisfied:
            return []

        self.updateSemester(semNum,currentSubject,optionSelected)
        years = self.separateSemesterPerYears()
        
        self.saveToJson(years,"results.json")
        return years 
        
# algo = Algo()

# print(algo.createMap())

algoUtil = Algo()


'''

mandatory -> take all (67 credits)

general electives -> 15 credits from any course


gen_ed can be taken up to max 42 credits and minimum 27

humanities and fine arts ->  9 credits genedcol = humanities

social and sciences -> 9 credits (genED col = SocialandBehaviouralScience)

first-year-courses -> 3 crdits genED= WrittenAndOral

communication proficiency ->3 credits "genEd": "WrittenAndOral"

american history -> 3 credits (course_name prefix = "american")

other Requirements				- 3credits

Junior Level English Competiton[ENGL3130, make a entry ]	- 3credits




+ math pre-requisties




'''

